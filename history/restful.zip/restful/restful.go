package restful

// //组件
// func Mount(cp ComponentParam) {
// 	//初始化
// }
